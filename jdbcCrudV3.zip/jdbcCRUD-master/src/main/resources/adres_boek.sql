-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: adres_boek
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

DROP DATABASE IF EXISTS adres_boek;
CREATE DATABASE adres_boek;
USE adres_boek;
--
-- Table structure for table `contact_informatie`
--

DROP TABLE IF EXISTS `contact_informatie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_informatie` (
  `id` int NOT NULL AUTO_INCREMENT,
  `adres` varchar(50) NOT NULL,
  `telefoon_nummer` int NOT NULL,
  `persoon_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_informatie`
--

LOCK TABLES `contact_informatie` WRITE;
/*!40000 ALTER TABLE `contact_informatie` DISABLE KEYS */;
INSERT INTO `contact_informatie` VALUES (1,'suriname straat 15',2345672,1),(2,'Soelastraat 12',6546654,2);
/*!40000 ALTER TABLE `contact_informatie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persoon`
--

DROP TABLE IF EXISTS `persoon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `persoon` (
  `id` int NOT NULL AUTO_INCREMENT,
  `naam` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `naam` (`naam`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persoon`
--

LOCK TABLES `persoon` WRITE;
/*!40000 ALTER TABLE `persoon` DISABLE KEYS */;
INSERT INTO `persoon` VALUES (1,'Maarten'),(2,'Yasmine');
/*!40000 ALTER TABLE `persoon` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-26 20:16:41

DROP TABLE IF EXISTS adres_boek.land;

CREATE TABLE `adres_boek`.`land` (
  id INT NOT NULL AUTO_INCREMENT,
  naam VARCHAR(45) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE INDEX naam_uk (naam));

insert into adres_boek.land
values(1,'Suriname');

ALTER TABLE `adres_boek`.`contact_informatie`
ADD COLUMN `land_id` INT NOT NULL DEFAULT 1 AFTER `persoon_id`,
ADD INDEX `land_fk_idx` (`land_id`);

ALTER TABLE `adres_boek`.`contact_informatie`
ADD CONSTRAINT `land_fk`
  FOREIGN KEY (`land_id`)
  REFERENCES `adres_boek`.`land` (`id`);





