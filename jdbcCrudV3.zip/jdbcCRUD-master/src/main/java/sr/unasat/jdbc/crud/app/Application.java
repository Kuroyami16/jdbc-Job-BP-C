package sr.unasat.jdbc.crud.app;

import sr.unasat.jdbc.crud.entities.ContactInformatie;
import sr.unasat.jdbc.crud.entities.Job;
import sr.unasat.jdbc.crud.entities.Persoon;
import sr.unasat.jdbc.crud.repositories.ContactInformatieRepository;
import sr.unasat.jdbc.crud.repositories.JobRepository;
import sr.unasat.jdbc.crud.repositories.LandRepository;
import sr.unasat.jdbc.crud.repositories.PersoonRepository;

import java.util.List;

public class Application {

    public static void main(String[] args) {


        PersoonRepository persoonRepo = new PersoonRepository();
        List<Persoon> persoonList = persoonRepo.findAllRecords();
        for (Persoon persoon : persoonList) {
            System.out.println(persoon);
        }

        // Persoon pairin = new Persoon("Pairin");
        // persoonRepo.insertOneRecord(pairin);

        ContactInformatieRepository ciRepo = new ContactInformatieRepository();
        List<ContactInformatie> contactList = ciRepo.findAllRecords();
        for (ContactInformatie contact : contactList) {
            System.out.println(contact);
        }


        LandRepository landRepo = new LandRepository();

        JobRepository jobRepo = new JobRepository();
        List<Job> jobList = jobRepo.findAllRecords();
        for (Job job : jobList) {
            System.out.println(job);
        }


        JobRepository PersoonJob = new JobRepository();
        System.out.println(PersoonJob);
    }
}


    // }


    //      Land guyana = new Land("Guyana");
    //      landRepo.insertOneRecord(guyana);

    //    List<Land> landList = landRepo.findAllRecords();
    //    for (Land land : landList) {
    //       System.out.println(land);
    //  }
    // {
    //  Persoon person = new Persoon("Maarten");
    //  persoonRepo.deleteOneRecord(person);

    //    int result = persoonRepo.insertOneRecord(new Persoon("Ellen"));
    //  System.out.println(result);
 /*   ContactInformatieRepository ci = new ContactInformatieRepository();
    ContactInformatie recordFound = ci.findOneRecord(1234, "Manjastraat 10");
      System.out.println("single record: "+ci);
       recordFound.setTelefoonNummer(8888);
      recordFound.getPersoon().

    setId(4);
      ci.updateOneRecord(recordFound);
      System.out.println(ci.findAllRecords()); */


