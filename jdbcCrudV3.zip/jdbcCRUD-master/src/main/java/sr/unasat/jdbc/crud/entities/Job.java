package sr.unasat.jdbc.crud.entities;

public class Job {

    private Integer id;

    private Integer persoon_id;
    private Persoon persoon;


    private String persoon_naam;

    private String functie;
    private String bedrijfnaam;
    private String bedrijfadres;


    public Job(Integer id, Integer persoon_id, Persoon persoon, String persoon_naam, String functie, String bedrijfnaam, String bedrijfadres) {
        this.id = id;
        this.persoon_id = persoon_id;
        this.persoon = persoon;
        this.persoon_naam = persoon_naam;
        this.functie = functie;
        this.bedrijfnaam = bedrijfnaam;
        this.bedrijfadres = bedrijfadres;
    }

    public Job(String functie, String bedrijfnaam, Persoon persoon, String bedrijfadres) {
        this.persoon = persoon;
        this.functie = functie;
        this.bedrijfnaam = bedrijfnaam;
        this.bedrijfadres = bedrijfadres;
    }

    public Job (Persoon persoon, String functie, String bedrijfnaam, String bedrijfadres) {
        this.persoon = persoon;
        this.functie = functie;
        this.bedrijfnaam = bedrijfnaam;
        this.bedrijfadres = bedrijfadres;
    }

    public Job(Integer id, Integer persoon_id, String persoon_naam, String functie, String bedrijfnaam, String bedrijfadres) {
    }

    public Job() {

    }

    public String getPersoon_naam() {
        return persoon_naam;
    }

    public void setPersoon_naam(String persoon_naam) {
        this.persoon_naam = persoon_naam;
    }

    public Integer getId() { return  id; }
    public void setId(Integer id) {this.id = id;}

    public Persoon getPersoon() { return persoon; }
    public void setPersoon(Persoon persoon) {this.persoon = persoon;}
    public String getFunctie() { return functie; }
    public void setFunctie(String functie) {this.functie = functie;}

    public Integer getPersoon_id() {
        return persoon_id;
    }

    public void setPersoon_id(Integer persoon_id) {
        this.persoon_id = persoon_id;
    }



    public String getBedrijfnaam () { return bedrijfnaam;}
    public void setBedrijfnaam (String bedrijfnaam) {this.bedrijfnaam = bedrijfnaam; }

    public String getBedrijfadres() {return bedrijfadres;}
    public void setBedrijfadres(String bedrijfadres) {this.bedrijfadres = bedrijfadres;}

    @Override
    public String toString() {
        return "Job{" +
                "JobID=" + id +
                ", PersoonID=" + persoon_id +
                ", Naam=" + persoon_naam +
                ", Functie='" + functie + '\'' +
                ", Bedrijfnaam=" + bedrijfnaam +
                ", Bedrijfadres=" + bedrijfadres +
                '}';
    }
}


