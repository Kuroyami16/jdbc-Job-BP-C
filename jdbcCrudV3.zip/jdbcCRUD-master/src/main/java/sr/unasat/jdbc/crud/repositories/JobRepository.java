package sr.unasat.jdbc.crud.repositories;

import sr.unasat.jdbc.crud.entities.Job;
import sr.unasat.jdbc.crud.entities.Persoon;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JobRepository {
    private Connection connection;

    public JobRepository() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("De driver is geregistreerd!");

            String URL = "jdbc:mysql://localhost:3306/adres_boek";
            String USER = "root";
            String PASS = "bestintheworld16";
            connection = DriverManager.getConnection(URL, USER, PASS);
            System.out.println(connection);
        } catch (ClassNotFoundException ex) {
            System.out.println("Error: unable to load driver class!");
            System.exit(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Job> findAllRecords() {
        List<Job> jobList = new ArrayList<Job>();
        Statement stmt = null;
        try {
            stmt = connection.createStatement();
            String sql = "select j.id,p.id pid, p.naam pnaam, j.functie, j.bedrijfnaam, j.bedrijfadres" +
                    " from job j" +
                    " join persoon p" +
                    " on p.id = j.persoon_id";
            ResultSet rs = stmt.executeQuery(sql);
            System.out.println("resultset: " + rs);
            while (rs.next()) {

                int id = rs.getInt("id");

                int persoonId = rs.getInt("pid");

                String persoonNaam = rs.getString("pnaam");
                Persoon persoon = new Persoon(persoonId, persoonNaam);

                String functie = rs.getString("functie");

                String bedrijfnaam = rs.getString("bedrijfnaam");

                String bedrijfadres = rs.getString("bedrijfadres");



             /*  Job job = new Job();
               job.setPersoon(persoon);
               job.setFunctie(functie);
               job.setBedrijfadres(bedrijfadres);
               job.setBedrijfnaam(bedrijfnaam);
               job.setId(id);
               job.setPersoon_id(persoonId); */

                jobList.add((new Job(id, persoonId, persoon, persoonNaam, functie, bedrijfnaam, bedrijfadres)));


                //persoonList.add (new Persoon(rs.getInt("id"));

             /*   System.out.println("Persoon:" + persoonNaam);
                System.out.println("Functie:" + functie);
                System.out.println("Bedrijfnaam:" + bedrijfnaam);
                System.out.println("Bedrijfadres:" + bedrijfadres); */


            }
            rs.close();


        } catch (SQLException e) {


        } finally {

        }
        return jobList;
    }

    public Job findOneRecord(String bNaam, String bAdres) {
        Job job = null;
        PreparedStatement stmt = null;
        try {
            String sql = "select job.id, p.id pid,p.naam pnaam job.functie,job.bedrijfnaam, job.bedrijfadres," +
                    " from job job" +
                    " join persoon p" +
                    " on p.id = job.persoon_id" +
                    " join bedrijf bn" +
                    " on bn.id = job.persoon_id where job.functie = ? or job.bedrijfadres = ?";
            stmt = connection.prepareStatement(sql);
            stmt.setString(1, bNaam);
            stmt.setString(2, bAdres);
            ResultSet rs = stmt.executeQuery();
            System.out.println("resultset: " + rs);

            if (rs.next()) {
                int id = rs.getInt("id");
                int persoonId = rs.getInt("pid");
                String persoonNaam = rs.getString("pnaam");
                Persoon persoon = new Persoon(persoonId, persoonNaam);
                String functie = rs.getString("functie");
                String bedrijfnaam = rs.getString("bedrijfnaam");
                String bedrijfadres = rs.getString("bedrijfadres");


                job = new Job(id, persoonId, persoon, persoonNaam, functie, bedrijfnaam, bedrijfadres);
            }
            rs.close();


        }catch(SQLException e) {

        } finally {

        }
        return job;
    }

    public int insertARecord (Job job) {
        PreparedStatement stmt = null;
        int result = 0;
        try {
            String sql = "insert into job (id, functie, bedrijfnaam, bedrijfadres) VALUES (?, ?, ?, ?)";
            stmt = connection.prepareStatement(sql);
            stmt.setInt(1, job.getId());
            stmt.setString(2, job.getFunctie());
            stmt.setString(3, job.getBedrijfnaam());
            stmt.setString(4, job.getBedrijfadres());
            System.out.println("resultset: " + result);

        } catch (SQLException e) {

        } finally {

        }
        return result;
    }

    public int deleteOneRecord(Job job) {
        PreparedStatement stmt = null;
        int result = 0;
        try {
            String sql = "DELETE FROM job WHERE job.id = ?";
            stmt = connection.prepareStatement(sql);
            stmt.setInt(1, job.getId());
            result = stmt.executeUpdate();
            System.out.println("deleted: " + job.getId());

        } catch (SQLException e) {

        } finally {

        }
        return result;

    }

    public int updateOneRecord(Job job) {
        PreparedStatement stmt = null;
        int result = 0;
        try {
            String sql = "update job j set j.functie = ?, j.persoon_id = ? where j.id = ?";
            stmt = connection.prepareStatement(sql);
            stmt.setInt(1, job.getId());
            stmt.setInt(2, job.getPersoon().getId());
            stmt.setString(3, job.getFunctie());
            result = stmt.executeUpdate();
            System.out.println("resultset: " + result);

        } catch (SQLException e) {

        } finally {
        }
        return result;
    }

    public List<Job> PersonWithJobRecord() {
        List<Job> persoonJobList = new ArrayList<Job>();
        Statement stmt = null;
        System.out.println("Joining 2 MySQL Tables using Natural Join");
        try {
            stmt = connection.createStatement();
            String sql = "select * from"
                    + " persoon "
                    + " join "
                    + " job ";

            ResultSet rs = stmt.executeQuery(sql);


            System.out.println(" Naam "
                    + " Functie "
                    + " Bedrijfnaam "
                    + " Bedrijfadres ");

            while (rs.next()) {
                String persoonNaam = rs.getString("pnaam");
                String functie = rs.getString("functie");
                String bedrijfnaam = rs.getString("bedrijfnaam");
                String bedrijfadres = rs.getString("bedrijfadres");
                System.out.format("%10s%10s%10s%10s%20s\n", persoonNaam, functie, bedrijfnaam, bedrijfadres);

            }
            connection.close();
        } catch (SQLException s) {
            System.out.println("SQL statement is not executed!");

        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            return persoonJobList;
        }


    }

    public class GFG {

        // Main driver method
        public void main(String[] args)
        {

            // Display message
            System.out.println(
                    "Joining 2 MySQL tables using Natural Join");

            // DB 'Connection' object of Connection class
            Connection con = null;

            // Try block to check exceptions
            try {
                // Step 2: Load and register drivers

                // Loading driver
                // Jars(relevant) or mysql-connector-java-8.0.22
                // in build path of project
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Registering driver

                // test is database name here
                // serverTimezone=UTC, if not provided we will
                // have java.sql.SQLException
                // Credentials here are root/""
                // i.e. username is root
                // password is ""

                // Step 3: Establishing a connection
                con = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/adres_boek",
                        "root", "bestintheworld16");

                // Try block to check java exceptions
                try {

                    // Step 4: Write a statement
                    // Join
                    Statement st = con.createStatement();
                    // Combining two tables in query using
                    // NATURAL JOIN studentsdetails columns :
                    // Name,caste,NeetMarks,gender
                    // studentspersonaldetails columns :
                    // Name,Address,email

                    // In both tables, connecting columns are
                    // Name Name is taken Here res will have the
                    // data from
                    // both studentsdetails and
                    // studentspersonaldetails whenever "Name"
                    // in both tables are matched join
                    ResultSet res = st.executeQuery(
                            "SELECT * FROM "
                                    + "persoon"
                                    + " NATURAL JOIN "
                                    + "job");

                    // Step 5: Execute the query
                    System.out.println("   Naam"
                            + "    Functie"
                            + "     Bedrijfnaam  "
                            + "Bedrijfadres");

                    // Step 6: Process the statements
                    // Iterate the resultset and retrieve the
                    // required fields
                    while (res.next()) {
                        String persoonNaam = res.getString("pnaam");
                        String functie = res.getString("functie");
                        String bedrijfnaam = res.getString("bedrijfnaam");
                        String bedrijfadres
                                = res.getString("bedrijfadres");

                        // Beautification of output
                        System.out.format(
                                "%10s%10s%10s%10s%20s\n", persoonNaam,
                                functie, bedrijfnaam, bedrijfadres);
                    }

                    // Step 7: Close the connection
                    con.close();
                }

                // Catch bloack to handle DB exceptions
                catch (SQLException s) {

                    // If there is error in SQL query, this
                    // exception occurs
                    System.out.println(
                            "SQL statement is not executed!");
                }

                // Catch bloack to handle generic java
                // exceptions
            }
            catch (Exception e) {

                // General exception apart from SQLException are
                // caught here
                e.printStackTrace();
            }
        }
    }


}






