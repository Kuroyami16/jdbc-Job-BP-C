# jdbcCRUD
jdbc Crud example application

#SQL Script
De sql script is geplaats in de resource folder.
De sql script bevat de schema & insert statements.

#Opdracht
Maak het project af conform de beroepsproduct opdracht van blok 2.1.
